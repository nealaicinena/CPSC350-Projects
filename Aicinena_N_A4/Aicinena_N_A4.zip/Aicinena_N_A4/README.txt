Name
- Neal Aicinena
ID
- 2428026
Email
- aicinena@chapman.edu

Course number and section
- CPSC 350-03

Assignment
- MP4: The Waiting Game

Source Files:
- Customer.cpp
- Customer.h
- DblList.h
- input.txt
- ListNode.h
- ListQueue.h 
- main.cpp
- Office.h 
- ServiceCenter.cpp
- ServiceCenter.h 
- TickInfo.cpp
- TickInfo.h 
- Window.cpp
- Window.h 

Sources:
- 
Collaborators:
- Bader Aldawoodi

How to run your program/programs:
- compile: g++ *.cpp
- run: ./a.out