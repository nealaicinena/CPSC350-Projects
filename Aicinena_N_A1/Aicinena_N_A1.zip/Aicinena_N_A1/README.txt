Name
- Neal Aicinena
ID
- 2428026
Email
- aicinena@chapman.edu

Course number and section
- CPSC 350-03

Assignment
- MP1: Robber Langauge Translation

Source Files:
- Model.h 
- Model.cpp
- Translator.h 
- Translator.cpp
- FileProcessor.h
- FileProcessor.cpp
- main.cpp
- inputFile.txt
- translator.html

Sources:
- 
Collaborators:
-

How to run your program/programs:
- compile: g++ *.cpp
- run: ./a.out