#include <iostream>
#include "DatabaseSystem.h"

int main(){
    DatabaseSystem myDatabase;
    myDatabase.run(); //runs simulation of database all the way through

    return 0;
}