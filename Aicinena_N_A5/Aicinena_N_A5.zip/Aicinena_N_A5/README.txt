Name
- Neal Aicinena
ID
- 2428026
Email
- aicinena@chapman.edu

Course number and section
- CPSC 350-03

Assignment
- MP5: LB-BSTs

Source Files:
- Database.cpp
- Database.h
- DatabaseSystem.cpp
- DatabaseSystem.h
- Faculty.cpp
- Faculty.h
- IntArray.cpp
- IntArray.h 
- LazyBST.h 
- Student.cpp
- Student.h 
- TreeNode.h 
- main.cpp
- runLog.txt

Sources:
- 
Collaborators:
- Bader Aldawoodi

How to run your program/programs:
- compile: g++ *.cpp
- run: ./a.out