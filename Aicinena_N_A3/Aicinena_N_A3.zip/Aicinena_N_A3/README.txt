Name
- Neal Aicinena
ID
- 2428026
Email
- aicinena@chapman.edu

Course number and section
- CPSC 350-03

Assignment
- MP2: Do You See What I See.

Source Files:
- GenStack.h
- MonoStack.h
- SpeakerView.h
- SpeakerView.cpp
- main.cpp
- input.txt

Sources:
- https://cplusplus.com/reference/string/stod/
Collaborators:
-

How to run your program/programs:
- compile: g++ *.cpp
- run: ./a.out