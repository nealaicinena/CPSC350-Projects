Name
- Neal Aicinena
ID
- 2428026
Email
- aicinena@chapman.edu

Course number and section
- CPSC 350-03

Assignment
- MP2: Not So Super Mario Bros.

Source Files:
- Mario.h
- Mario.cpp
- Enemy.h
- Koopa.h
- Koopa.cpp
- Goomba.h
- Goomba.cpp
- Boss.h
- Boss.cpp
- Level.h
- Level.cpp
- World.h
- World.cpp
- FileReader.h
- FileReader.cpp
- Game.h
- Game.cpp
- main.cpp
- input.txt
- output.txt

Sources:
- https://en.cppreference.com/w/cpp/numeric/random/random_device
Collaborators:
-

How to run your program/programs:
- compile: g++ *.cpp
- run: ./a.out output.txt