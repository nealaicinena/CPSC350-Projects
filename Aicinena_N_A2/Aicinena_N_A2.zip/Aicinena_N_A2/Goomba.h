#include "Enemy.h"

class Goomba : public Enemy {
    public :
        Goomba(); //default constructor
        ~Goomba(); //default destructor
};