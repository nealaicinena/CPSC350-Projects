#include "Koopa.h"

Koopa::Koopa() {
    fightWinProb = 35; //35% chance of beating mario
    powerDecrease = 1; //take away 1 power from mario
    letter = 'k'; //k for koopa
}

Koopa::~Koopa() {
    
}