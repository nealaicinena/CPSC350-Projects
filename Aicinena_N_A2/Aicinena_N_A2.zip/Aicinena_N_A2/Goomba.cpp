#include "Goomba.h"

Goomba::Goomba() {
    fightWinProb = 20; //20% chance of beating mario
    powerDecrease = 1; //power level decrease of 1
    letter = 'g'; //g for goomba
}

Goomba::~Goomba() {
    
}

