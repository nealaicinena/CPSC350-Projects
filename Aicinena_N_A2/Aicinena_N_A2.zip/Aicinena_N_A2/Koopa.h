#include "Enemy.h"

class Koopa : public Enemy {
    public:
        Koopa(); //default constructor
        ~Koopa(); //default destructor
};